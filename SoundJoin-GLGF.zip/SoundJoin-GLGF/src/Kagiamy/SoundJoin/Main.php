<?php

namespace Kagiamy\SoundJoin;

use pocketmine\plugin\PluginsBase;
use pocketmine\event\Listerner;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\level\sound\Sound;
use pocketmine\level\sound\PopSound;
use pocketmine\utils\Config;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\level\sound\DoorSound;
use pocketmine\level\sound\BatSound;

class Events extends PluginBase implemenrs Listener{

public function onEnbale() {
$this->getServer()->getPluginManager()->registerEvents($this, $this);
	  $this->config = (new Config($this->getDataFolder()."config.yml", Config::YAML))->getAll();
	   $this->saveDefaultConfig();
	    $this->getLogger()->info("[GLGFSoundJoin] Plugin has benn enable");
}
	    
public function onJoin(PlayerJoinEvent $event){
	   $JoinMessage = $this->getConfig()->get("JoinMessage"); // So it can pull the users config (Message) via config :)
	    $Sound = $this->getConfig()->get("Sound"); // So it can pull the sound the users wants
	    $player = $event->getPlayer();
	    $event->getPlayer->sendMessage("$JoinMessage")
	    $player->getLevel()->addSound(new $Sound($player), [$player]);
}	    	    
}	    	    