<?php

namespace Kagiamy;

use pocketmine\plugins\PluginBase;

class Kagiamy extends PluginsBase {

		public function onEnable() {
			
	}	
		
}